# BinStudentDB Test Report — Run func_1794002198

**Status:** FAIL (0/11 passed)

## Test Summary

| Test ID | Scenario | Status | Duration (ms) | Details |
|---|---|---|---|---|
| CU-001 | Create Student | FAIL | 97 | HTTP request POST http://127.0.0.1:65150/v1/students failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| CU-002 | Duplicate ID Rejection | FAIL | 0 | HTTP request POST http://127.0.0.1:65150/v1/students failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| CU-003 | Read Student Point Lookup | FAIL | 23 | HTTP request GET http://127.0.0.1:65150/v1/students/20240101 failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| CU-004 | Read Missing Record 404 | FAIL | 0 | HTTP request GET http://127.0.0.1:65150/v1/students/99999999 failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| CU-005 | Update Student Record | FAIL | 14 | HTTP request PUT http://127.0.0.1:65150/v1/students/20240101 failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| CU-006 | Delete Student Record | FAIL | 0 | HTTP request DELETE http://127.0.0.1:65150/v1/students/20240101 failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| CU-007 | Validation Error 422 | FAIL | 15 | HTTP request POST http://127.0.0.1:65150/v1/students failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| TX-001 | Atomic Batch Execution | FAIL | 0 | HTTP request POST http://127.0.0.1:65150/v1/tx failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| SQ-001 | Sequential Scan with Filter | FAIL | 0 | HTTP request GET http://127.0.0.1:65150/v1/students?mode=scan&cursor=0&limit=1000&department=Mathematics failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| IR-001 | Indexed Range Query | FAIL | 0 | HTTP request GET http://127.0.0.1:65150/v1/students?mode=index&from=20240200&to=20240250&limit=1000 failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |
| VA-001 | Online Invariant Verification | FAIL | 0 | HTTP request GET http://127.0.0.1:65150/v1/admin/verify failed: <urlopen error [WinError 10013] An attempt was made to access a socket in a way forbidden by its access permissions> |

## Environment

```json
{
  "os": "Windows",
  "os_release": "11",
  "architecture": "AMD64",
  "cpu_count": 16,
  "total_ram_gb": 0.0,
  "python_version": "3.14.9"
}
```

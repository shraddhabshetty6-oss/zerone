# BinStudentDB Test Report — Run func_1794002383

**Status:** PASS (11/11 passed)

## Test Summary

| Test ID | Scenario | Status | Duration (ms) | Details |
|---|---|---|---|---|
| CU-001 | Create Student | PASS | 17 |  |
| CU-002 | Duplicate ID Rejection | PASS | 1 |  |
| CU-003 | Read Student Point Lookup | PASS | 0 |  |
| CU-004 | Read Missing Record 404 | PASS | 0 |  |
| CU-005 | Update Student Record | PASS | 1 |  |
| CU-006 | Delete Student Record | PASS | 35 |  |
| CU-007 | Validation Error 422 | PASS | 15 |  |
| TX-001 | Atomic Batch Execution | PASS | 31 |  |
| SQ-001 | Sequential Scan with Filter | PASS | 0 |  |
| IR-001 | Indexed Range Query | PASS | 14 |  |
| VA-001 | Online Invariant Verification | PASS | 0 |  |

## Environment

```json
{
  "os": "Windows",
  "os_release": "11",
  "architecture": "AMD64",
  "cpu_count": 16,
  "total_ram_gb": 0.0,
  "python_version": "3.14.9"
}
```

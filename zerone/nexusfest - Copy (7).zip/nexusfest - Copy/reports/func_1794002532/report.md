# BinStudentDB Test Report — Run func_1794002532

**Status:** PASS (11/11 passed)

## Test Summary

| Test ID | Scenario | Status | Duration (ms) | Details |
|---|---|---|---|---|
| CU-001 | Create Student | PASS | 15 |  |
| CU-002 | Duplicate ID Rejection | PASS | 0 |  |
| CU-003 | Read Student Point Lookup | PASS | 0 |  |
| CU-004 | Read Missing Record 404 | PASS | 0 |  |
| CU-005 | Update Student Record | PASS | 0 |  |
| CU-006 | Delete Student Record | PASS | 1 |  |
| CU-007 | Validation Error 422 | PASS | 19 |  |
| TX-001 | Atomic Batch Execution | PASS | 46 |  |
| SQ-001 | Sequential Scan with Filter | PASS | 15 |  |
| IR-001 | Indexed Range Query | PASS | 15 |  |
| VA-001 | Online Invariant Verification | PASS | 15 |  |

## Environment

```json
{
  "os": "Windows",
  "os_release": "11",
  "architecture": "AMD64",
  "cpu_count": 16,
  "total_ram_gb": 0.0,
  "python_version": "3.14.9"
}
```
